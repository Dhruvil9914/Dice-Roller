﻿Public Class Form1
    Private Sub tmrDice_Tick(sender As Object, e As EventArgs) Handles tmrDice1.Tick

    End Sub
End Class
